# Patches for connector-ng 7.1.0 defects (proposed for 7.1.1)

Six fixes for defects found while building and black-box testing the 6.x → 7.1.0 migration tool. Each patch contains the
failing test and the fix, and is made against `develop` of https://github.com/e-codex/connector-ng at
`4ea94b21 chore: fix the version tag (#388)` (the 7.1.0 release).

7.1.0 is released, so the fixes are proposed for 7.1.1: each patch also adds its line to a new `[7.1.1] - unreleased` section
(`### Fixed`) of `CHANGELOG.md` and to `== 7.1.1 (unreleased)` → `==== Fixes` of
`connector-documentation/src/docs/asciidoc/changelog/changelog-7.x.x.adoc`. The first patch creates the sections.

| Patch | Defect | Test |
|---|---|---|
| `0001-fix-dbscripts-…` | `dbscripts/initial/postgres.sql` declares the check on `connector_messages.status` with the name of the check on `direction`. PostgreSQL rejects it and creates only 3 of 19 tables. | `PostgresInitialScriptIT` (new, tag `integration`, PostgreSQL 17 via Testcontainers): runs the shipped script, expects 19 tables. Adds `testcontainers-postgresql` and the PostgreSQL driver to `connector-integrationtest` tests. |
| `0002-fix-persistence-…` | Evidence correlation looks messages up by backend message id and ebMS id with single-result queries; neither column is unique. A resent backend id or messages migrated from 6.x make every evidence for that id fail with `IncorrectResultSizeDataAccessException`. The newest message now wins. | `ConnectorDBMessageRepositoryTest.FindReferencedBusinessMessage`: two new tests with a newer message reusing both ids (fixture `sql/message-duplicate-identifiers.sql`). |
| `0003-fix-rest-…` | `GET /api/v1/admin/messages?size=500` (or `size=0`, `page=-1`) answers 500: `ConnectorPageRequest`'s `IllegalArgumentException` is not mapped. It is now `InvalidPageRequestException` (still an `IllegalArgumentException`), mapped to 400. | `ConnectorMessageAdminControllerTest.ListMessages`: parameterized test for the three cases. |
| `0004-fix-pmode-…` | A P-Mode with two services of the same value and different types is accepted, but message verification and AS4 property storage look the service up by name only and fail for those services. The lookup now uses name and type. | `ConnectorDBProcessingModeServiceRepositoryTest.FindByNameAndTypeAndBusinessDomain` (fixture `sql/processing-mode-service-same-name.sql`); `ConnectorBusinessMessageVerifierServiceTest` updated to the new port method. |
| `0005-fix-config-…` | `LinkPartnerDetailProperties.pushAddress` is `@NotNull`: 7.1.0 does not start unless every backend partner has a `push-address`, also pull (passive) partners it never calls. `LinkPartnerProperties` already requires it for push partners; the `@NotNull` is dropped. | `LinkPartnerPropertiesValidationTest` (new): passive without address valid; push without address, and push with a non-http address, rejected with one message each. |
| `0006-fix-evidence-…` | An evidence that can no longer change a message (for example DELIVERY after the NON_DELIVERY of an evidence timeout, or a late evidence for a message migrated from 6.x) is logged as ignored, but the `ConnectorEvidenceNotRelevantException` leaving the `@Transactional` verifier already marked the JMS listener's transaction rollback-only. The trigger is redelivered and ends in `ActiveMQ.DLQ`. The verifier now declares `noRollbackFor` that exception. | `ConnectorMessageEvidenceVerifierTransactionTest` (new): the verifier behind Spring's `TransactionInterceptor` inside an outer transaction; fails with `UnexpectedRollbackException` without the fix. |

## Apply

From a clone of connector-ng, with this folder (unzipped from `DELETE-BEFORE-MERGE/connector-ng-7.1.1-patches.zip`)
next to it:

```bash
git fetch origin
git switch -c fix/7.1-defects origin/develop
git am connector-ng-7.1.1-patches/0*.patch
```

`git am` keeps each patch as its own commit, with its message and author. If `develop` moved on and a patch does not apply
cleanly, run `git am --3way connector-ng-7.1.1-patches/0*.patch`, resolve, `git add`, then
`git am --continue`. To check before applying: `git apply --check connector-ng-7.1.1-patches/0*.patch`.

## Verify

```bash
./gradlew :connector-domain:test :connector-application:test :connector-infrastructure:test
./gradlew :connector-integrationtest:integrationTest --tests '*PostgresInitialScriptIT'   # needs Docker
./gradlew checkstyleMain checkstyleTest
```

All tests of `connector-domain`, `connector-application` and `connector-infrastructure` pass with the patches, and checkstyle
reports nothing in the changed files. The patches were applied with `git am` to a fresh `develop` and tested there (unit tests of the three modules, checkstyle,
`PostgresInitialScriptIT`).

Pushing and opening the pull request are up to you; nothing was pushed.

## Not patched

* The documentation of the purge of unresolved messages (`connector.file-deletion.unresolved-messages.threshold`) after a
  migration is covered by the migration chapter of the documentation.
